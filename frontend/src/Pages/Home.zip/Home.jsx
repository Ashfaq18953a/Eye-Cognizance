import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import homedoc from "../assets/Image/homedoc.png";
import consult from "../assets/Image/consult.png";
import criwork from "../assets/Image/criwork.png";
import review from "../assets/Image/review.jpg";
import heroimg from "../assets/Image/heroimg.png";
import docimg from "../assets/Image/doc.png";
import Banner from "../Components/Banner";
import Include from "../Components/Include";
import Heroconsultation from "../Components/HeroConsultation";

const ReviewCarousel = () => {
  const scrollRef = useRef(null);

  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;

    let x = 0;

    const scroll = setInterval(() => {
      x += 1;

      // Loop when reaching the end
      if (x >= container.scrollWidth - container.clientWidth) {
        x = 0;
      }

      container.scrollTo({
        left: x,
        behavior: "smooth",
      });
    }, 20);

    return () => clearInterval(scroll);
  }, []);

  const cards = [
    {
      text: "Very professional and friendly experience. My eye redness was cured in one consultation.",
      name: "Deepa M, Alappuzha",
      rating: "★★★★☆",
    },
    {
      text: "Doctor was very calm and explained everything clearly. Highly recommended.",
      name: "Amal K, Kochi",
      rating: "★★★★★",
    },
    {
      text: "Great treatment. My mother’s vision issues improved significantly.",
      name: "Asha P, Trivandrum",
      rating: "★★★★☆",
    },
  ];

  const loopCards = [...cards, ...cards];

  return (
    <div className="w-full mt-16 px-6">
      {/* HEADING */}
      <h1 className="text-3xl md:text-5xl font-bold text-[#2C3A23] text-center">
        What Patients Say
      </h1>
      <p className="text-gray-700 text-center mt-3 mb-10 text-lg">
        Hear from patients who trust Dr. Maimunnissa for professional and
        compassionate eye care.
      </p>

      {/* ⭐ SCROLL VIEW */}
      <div
        ref={scrollRef}
        className="flex gap-10 overflow-x-auto scroll-smooth py-6  no-scrollbar min-w-full"
      >
        {loopCards.map((card, idx) => (
          <div
            key={idx}
            className="relative min-w-[300px] md:min-w-[380px] max-w-[400px] 
                       bg-[#B0D07D] p-6 rounded-2xl shadow-lg flex-shrink-0"
          >
            {/* ⭐ Profile Image on top-left (FULL CIRCLE) */}
            <div
              className="absolute -top-6 -left-6 w-20 h-20 rounded-full 
                            overflow-hidden border-4 border-white shadow-md bg-white"
            >
              <img
                src={review}
                alt="profile"
                className="w-full h-full object-cover"
              />
            </div>

            {/* ⭐ Rating */}
            <div className="absolute top-4 right-4 text-yellow-500 text-lg">
              {card.rating}
            </div>

            {/* ⭐ Card Content */}
            <div className="mt-10">
              <p className="text-black text-sm md:text-base leading-relaxed">
                {card.text}
              </p>
              <p className="text-right font-semibold mt-4">{card.name}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};



export default function HeroBanner() {
  const navigate = useNavigate();

  return (
    <div>
      <Banner />

      {/* TRUSTED BY */}
      <div className="bg-[#B0D07D] text-2xl flex flex-col items-center justify-center text-center p-6">
        <p className="font-semibold">Trusted by thousands of patients</p>

        <div className="flex flex-col md:flex-row md:items-center md:justify-center gap-3 mt-3 text-2xl">
          <p>NABH Certified</p>
          <p className="hidden md:block">|</p>
          <p>10,000+ Eye Patients</p>
          <p className="hidden md:block">|</p>
          <p>100% Confidential Care</p>
        </div>
      </div>

     <div className="w-full bg-white">
  {/* MAIN GRID */}
<div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-center">

  {/* LEFT — TEXT CONTENT */}
  <div className="md:col-span-7">
    <h1 className="text-3xl ml-20 md:text-5xl font-bold text-[#2C3A23] leading-snug text-left">
      Meet Dr. Maimunnissa — Your <br className="hidden md:block" />
      Eye Specialist Online
    </h1>

    <div className="max-w-4xl ml-20 text-left mt-6 text-gray-700 text-lg space-y-5">
      <p>
        Dr. Maimunnissa is a compassionate and highly skilled ophthalmologist
        dedicated to providing exceptional care for patients of all ages. With
        years of expertise in cataract management, retinal disorders, and
        diabetic eye disease, she has helped countless individuals restore and
        protect their vision.
      </p>
      <p>
        Her approach goes beyond just treatment — she focuses on truly
        understanding each patient’s concerns, offering gentle, personalized
        guidance that ensures comfort and confidence throughout the process.
      </p>
    </div>
  </div>

  {/* RIGHT — CIRCULAR DOCTOR IMAGE */}
  <div className="md:col-span-5 mt-10 flex justify-center sm:justify-end md:justify-end">
    <div
      className="relative w-full max-w-[420px] sm:max-w-[480px] md:max-w-[520px] lg:max-w-[560px] h-[360px] sm:h-[420px] md:h-[480px] lg:h-[540px]"
      style={{
        backgroundImage: `url(${docimg})`,
        backgroundRepeat: "no-repeat",
        backgroundPosition: "right center",
        backgroundSize: "contain",
      }}
    >
      <img
        src={homedoc}
        alt="Doctor"
        className="
          absolute
          md:left-[9%] sm:ml-28 sm:left-[9%]
          md:w-[66%] sm:w-[64%] lg:w-[74%]
          h-[95%] md:h-[74%] lg:h-[98%] sm:h-[98%]
          object-cover
          rounded-lg
        "
      />
    </div>
  </div>

</div>

{/* SECOND SECTION → MISSION + QUALIFICATION CARDS */}
<div className="grid grid-cols-1 md:grid-cols-11 md:gap-4 md:mt-[-40px] ml-10 mt-4">
  {/* LEFT: Mission box (md:8 columns) */}
  <div className="md:col-span-8">
    <div className="bg-[#414F31] text-white p-6 rounded-xl shadow-lg mb-8">
      <h4 className="text-3xl font-semibold mb-3">Mission</h4>
      <p className="text-lg leading-relaxed">
        To make expert eye care accessible to everyone through secure
        online consultations. Dr. Maimunnissa strives to provide
        compassionate, personalized treatment for every patient. Her
        goal is to combine medical excellence with modern technology —
        ensuring healthy vision, comfort, and trust anytime, anywhere.
      </p>
    </div>
  </div>
</div>

  
</div>


{/* QUALIFICATION CARDS */}
      <div className="grid grid-cols-1 ml-10 mr-10 sm:grid-cols-3 gap-6">
        <div className="bg-[#FFFECB] p-5 rounded-xl shadow">
          <h4 className="text-xl font-semibold">
            Qualified Ophthalmologist
          </h4>
          <p className="text-gray-700 mt-1">
            Trained at a reputed medical institution with strong clinical
            and academic foundation.
          </p>
        </div>

        <div className="bg-[#FFFECB] p-5 rounded-xl shadow">
          <h4 className="text-xl font-semibold">NABH Certified</h4>
          <p className="text-gray-700 mt-1">
            Committed to maintaining the highest standards of safety and
            patient care.
          </p>
        </div>

        <div className="bg-[#FFFECB] p-5 rounded-xl shadow">
          <h4 className="text-xl font-semibold">10,000+ Consultations</h4>
          <p className="text-gray-700 mt-1">
            Extensive experience in diagnosing and treating diverse eye
            conditions.
          </p>
        </div>
      </div>


      <Heroconsultation />
      {/* <div className="w-full md:mt-[-90px] md:px-6 py-2">
        <div className="grid grid-cols-2 md:grid-cols-2 pt-[-10] items-center">
         
          <div className="max-w-xl mx-auto">
            <h4 className="text-4xl p-3 sm:text2xl font-semibold text-[#2C3A23] mb-4">
              All consultations include:
            </h4>

            <ul className="space-y-3 md:gap-10 sm:text-xl text-gray-700 md:text-2xl">
              <li>✅ 100% Secure and Confidential Service</li>
              <li>✅ Free 7-Day Follow-Up</li>
              <li>✅ Digital Prescription</li>
            </ul>
          </div>

         
          <div className="flex justify-center md:justify-end">
            <img
              src={consult}
              alt="Consultation"
              className="w-full max-w-xl rounded-lg"
            />
          </div>
        </div>
      </div> */}

      <Include/>

      <div className="w-full md:mt-[-50px] text-center">
        {/* Heading */}
        <h1 className="text-3xl md:text-4xl font-bold text-[#2C3A23]">
          How It Works
        </h1>
        <p className="text-gray-700 mt-2 text-xl">
          Get expert eye care in just 3 easy steps
        </p>

        {/* Steps Grid */}
        <div className="relative grid grid-cols-1 md:grid-cols-3 gap-10 mt-16">
          {[1, 2, 3].map((num, index) => (
            <div
              key={index}
              className="bg-[#B0D07D] rounded-2xl p-5 shadow relative 
        flex flex-col justify-start min-h-[260px] w-full max-w-sm mx-auto"
            >
              {/* Circle + Number */}
              <div className="absolute -top-5 -left-5">
                <div className="relative">
                  <img src={criwork} className="w-40 h-40" alt="circle" />

                  <span
                    className="absolute ml-2 top-1/2 left-1/3 -translate-x-1/2 -translate-y-1/2 
              w-14 h-14 bg-[#414F31] text-white rounded-full flex items-center 
              justify-center text-xl font-bold"
                  >
                    {num}
                  </span>
                </div>
              </div>

              {/* Text Section Left Aligned */}
              <div className="mt-34 text-left">
                <h4 className="text-xl font-semibold text-[#2C3A23]">
                  {num === 1
                    ? "Book Appointment"
                    : num === 2
                    ? "Join the Call"
                    : "Get Prescription"}
                </h4>

                <p className="text-gray-700 mt-1 text-base">
                  {num === 1
                    ? "Choose type & preferred time"
                    : num === 2
                    ? "Receive link instantly via SMS/email"
                    : "Digital Rx with follow-up care"}
                </p>
              </div>

              {/* Arrow */}
              {index < 2 && (
                <div className="hidden md:block absolute top-34 right-[-46px]">
                  <svg width="50" height="26" viewBox="0 0 60 20" fill="none">
                    <line
                      x1="10"
                      y1="10"
                      x2="45"
                      y2="10"
                      stroke="#414F31"
                      strokeWidth="3"
                    />
                    <polygon points="45,5 55,10 45,15" fill="#414F31" />
                  </svg>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-[#FFFECB] p-10 rounded-2xl m-10 shadow">
        {/* Text Section */}
        <div className="space-y-2">
          {/* Heading with Star */}
          <h2 className="text-xl md:text-3xl font-semibold text-[#2C3A23] flex items-center gap-2">
            {/* Star Icon */}
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="#1E40AF"
              viewBox="0 0 24 24"
              className="w-6 h-6"
            >
              <path
                d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.548 8.279L12 18.896l-7.484 4.517 
        1.548-8.279L0 9.306l8.332-1.151z"
              />
            </svg>
            Bonus: Free Follow-Up
          </h2>

          {/* Description */}
          <p className="text-gray-700 md:text-xl leading-relaxed">
            All patients receive a free follow-up consultation within 7 days to
            ensure your recovery and <br />
            address any additional concerns.
          </p>
        </div>
      </div>

      <ReviewCarousel />

      <div className="bg-[#FFFECB] flex flex-wrap justify-center gap-10 md:gap-40 p-10 md:p-20 mt-10">
        {/* Block 1 */}
        <div className="flex flex-col items-center md:items-start gap-3 md:gap-5 md:pl-30">
          <h1 className="text-[#37AFE1] font-bold text-3xl md:text-5xl">
            10,000+
          </h1>
          <p className="text-lg md:text-xl text-[#2C3A23]">Happy Patients</p>
        </div>

        {/* Block 2 */}
        <div className="flex flex-col items-center md:items-start gap-3 md:gap-5 md:pl-30">
          <h1 className="text-[#35A114] font-bold text-3xl md:text-5xl">10+</h1>
          <p className="text-lg md:text-xl text-[#2C3A23]">Years Experience</p>
        </div>

        {/* Block 3 */}
        <div className="flex flex-col items-center md:items-start gap-3 md:gap-5 md:pl-30">
          <h1 className="text-[#AFAF03] font-bold text-3xl md:text-5xl">5.0</h1>
          <p className="text-lg md:text-xl text-[#2C3A23]">Average Rating</p>
        </div>
      </div>

      <div className="w-full py-10 px-4 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 items-center gap-5">
          {/* Left Side Image */}
          <div className="flex justify-center md:justify-start">
            <img src={heroimg} alt="Hero" className="w-full max-w-" />
          </div>

          {/* Right Side Content */}
          <div className="flex flex-col justify-center md:text-left text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-[#2C3A23] leading-snug">
              Take the First Step Toward Better <br /> Vision Today
            </h1>

            <p className="text-gray-700 text-lg md:text-xl mt-4">
              Your eyes deserve expert, gentle care — anytime, anywhere.
            </p>

            <div className="flex flex-col md:flex-row gap-4 mt-6">
              <button className="bg-[#37AFE1] px-6 py-3 rounded-full text-white font-semibold">
                Book Consultation
              </button>

              <button className="bg-[#08813A] px-6 py-3 rounded-full text-white font-semibold">
                Chat With Doctor
              </button>
            </div>
            {/* TRUSTED BY */}
            <div className=" text-2xl flex flex-col pr-20 items-center justify-center text-center p-6">
              <p className="font-semibold">Trusted by thousands of patients</p>

              <div className="flex flex-col md:flex-row md:items-center  gap-3 mt-3 text-lg">
                <p>NABH Certified</p>

                <p>10,000+ Eye Patients</p>

                <p>100% Confidential Care</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
